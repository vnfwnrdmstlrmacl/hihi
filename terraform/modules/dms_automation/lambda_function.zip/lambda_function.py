import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
dms = boto3.client('dms')

def lambda_handler(event, context):
    # 환경 변수에서 전체 ARN을 가져옴
    forward_arn = os.environ.get('FORWARD_TASK_ARN', '')
    reverse_arn = os.environ.get('REVERSE_TASK_ARN', '')

    logger.info("========== FAILOVER PROCESS START ==========")
    
    # 1. 스케줄 이벤트 무시
    if event.get("source") == "aws.events":
        logger.info("Skipping Schedule Event.")
        return {"status": "skipped"}

    # 2. DMS 이벤트 분석
    detail = event.get('detail', {})
    resources = event.get('resources', [])
    
    # 이벤트가 발생한 Task의 ARN 확인 (가장 확실한 방법)
    # event['resources'] 리스트에 보통 해당 Task의 전체 ARN이 들어있습니다.
    event_task_arn = resources[0] if resources else ""
    
    # 상세 데이터 문자열화 (상태 추출용)
    detail_str = str(detail).lower()
    
    logger.info(f"Detected Task ARN: {event_task_arn}")
    logger.info(f"Event Detail Summary: {detail_str[:200]}...") # 로그 제한 대비 일부만 출력

    # 3. 핵심 로직: 이벤트 발생 ARN이 내가 등록한 정방향 ARN과 같은지 비교
    if event_task_arn == forward_arn:
        # 상태값이 'stop'이나 'fail' 혹은 '중지'를 뜻하는 단어가 포함되어 있는지 확인
        # DMS 콘솔에서 '중지됨' 상태는 내부적으로 'stopped' 혹은 'stopped-by-user'임
        if any(keyword in detail_str for keyword in ['stop', 'fail', 'terminate']):
            logger.info("!!! MATCH FOUND: Forward Task is DOWN. Starting Reverse Task...")
            
            try:
                # 역방향 태스크 시작 시도
                dms.start_replication_task(
                    ReplicationTaskArn=reverse_arn,
                    StartReplicationTaskType='resume-processing'
                )
                logger.info("SUCCESS: Reverse Task resume command sent.")
            except Exception as e:
                logger.warning(f"Resume failed, trying full start: {e}")
                dms.start_replication_task(
                    ReplicationTaskArn=reverse_arn,
                    StartReplicationTaskType='start-replication'
                )
                logger.info("SUCCESS: Reverse Task full-start command sent.")
        else:
            logger.info("Task is not in a failure/stopped state. No action taken.")
    else:
        logger.info("Event is NOT for the target forward task. Ignoring.")

    return {"status": "process_completed"}
